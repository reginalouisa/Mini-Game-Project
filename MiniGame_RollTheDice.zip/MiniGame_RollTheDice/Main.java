import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        PairOfDice dice;
        int n = 0;

        dice = new PairOfDice();

        while (true) {
            System.out.println("\n========WELCOME TO ROLL THE DICE========");
            System.out.println("1. Bermain");
            System.out.println("2. Keluar");
            n = input.nextInt();
            if (n == 1) {
                for (int i = 1; i < 13; i++) {
                    System.out.println("\n1. Lempar");
                    System.out.println("2. Keluar dari permainan");
                    n = input.nextInt();
                    if (n == 1) {
                        System.out.println("\nLemparan ke:" + i);
                        dice.roll();
                        int dice1 = dice.getDice1();
                        int dice2 = dice.getDice2();
                        dice.setTotal(dice1, dice2);
                        dice.jumlahrole(dice1, dice2);
                        System.out.println("The dice come up " + dice1 + " and " + dice2);

                        System.out.println("Grafik Dadu");

                        for (int j = 0; j < dice1; j++) {
                            System.out.print("*");
                        }
                        System.out.println("");
                        for (int j = 0; j < dice2; j++) {
                            System.out.print("*");
                        }
                    }
                }
                System.out.println("\nJumlah poin:" + dice.getTotal());
                System.out.println("Nilai mean poin:" + dice.getMean());
                dice.hitung();
            }
            if (n == 2) {
                break;
            }
        }
    }
}
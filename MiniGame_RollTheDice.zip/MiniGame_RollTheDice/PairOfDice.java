import java.util.*;

public class PairOfDice {

   private int dice1;
   private int dice2;
   private int total;


   public HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

   public PairOfDice() {
      roll();
   }

   public void roll() {
      dice1 = (int) (Math.random() * 6) + 1;
      dice2 = (int) (Math.random() * 6) + 1;
   }

   public void setTotal(int dice1, int dice2) {
      this.total += (dice1 + dice2);
   }

   public int getDice1() {
      return dice1;
   }

   public int getDice2() {
      return dice2;
   }

   public int getTotal() {
      return this.total;
   }

   public double getMean() {
      return this.total / 12;
   }

   public void jumlahrole(int dice1, int dice2) {
      int count1 = this.map.getOrDefault(dice1, 0);
      this.map.put(dice1, count1 + 1);
      int count2 = this.map.getOrDefault(dice2, 0);
      this.map.put(dice2, count2 + 1);
   }

   public void hitung() {
      int maxValue = -1;
      int key = 0;
      for (Map.Entry<Integer, Integer> entry : this.map.entrySet()) {
         if (entry.getValue() > maxValue) {
            maxValue = entry.getValue();
            key = entry.getKey();
         }
      }
      System.out.println("Daftar dadu dengan jumlah kemunculan:" + this.map);
      System.out.println("NIlai modus poin & nilai dadu:" + maxValue + "\t" + key);
   }
}

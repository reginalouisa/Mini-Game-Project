package umn.ac.id.rollthedice;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    public static final Random RANDOM = new Random();
    private Button rollDices, keluar;
    private ImageView imageView1, imageView2;
    private TextView tvcount, tvtotal, tvmean, tvmaxValue, tvkey, tvstar1, tvstar2, tvstar3, tvstar4, tvstar5, tvstar6, tvstar7, tvstar8, tvstar9, tvstar10, tvstar11, tvstar12, tvstar13, tvstar14, tvstar15, tvstar16, tvstar17, tvstar18, tvstar19, tvstar20, tvstar21, tvstar22, tvstar23, tvstar24;
    public int sum=0, total=0, count=0, mean=0, maxValue=0, key=0;
    public String star1="", star2="", star3="", star4="", star5="", star6="", star7="", star8="", star9="", star10="", star11="", star12="", star13="", star14="", star15="", star16="", star17="", star18="", star19="", star20="", star21="", star22="", star23="", star24="";
    HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rollDices = (Button) findViewById(R.id.rollDices);
        keluar = (Button) findViewById(R.id.keluar);
        imageView1 = (ImageView) findViewById(R.id.imageView1);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        tvcount = (TextView) findViewById(R.id.count);
        tvtotal = (TextView) findViewById(R.id.total);
        tvmean = (TextView) findViewById(R.id.mean);
        tvmaxValue = (TextView) findViewById(R.id.maxValue);
        tvkey = (TextView) findViewById(R.id.key);
        tvstar1= (TextView) findViewById(R.id.star1);
        tvstar2= (TextView) findViewById(R.id.star2);
        tvstar3= (TextView) findViewById(R.id.star3);
        tvstar4= (TextView) findViewById(R.id.star4);
        tvstar5= (TextView) findViewById(R.id.star5);
        tvstar6= (TextView) findViewById(R.id.star6);
        tvstar7= (TextView) findViewById(R.id.star7);
        tvstar8= (TextView) findViewById(R.id.star8);
        tvstar9= (TextView) findViewById(R.id.star9);
        tvstar10= (TextView) findViewById(R.id.star10);
        tvstar11= (TextView) findViewById(R.id.star11);
        tvstar12= (TextView) findViewById(R.id.star12);
        tvstar13= (TextView) findViewById(R.id.star13);
        tvstar14= (TextView) findViewById(R.id.star14);
        tvstar15= (TextView) findViewById(R.id.star15);
        tvstar16= (TextView) findViewById(R.id.star16);
        tvstar17= (TextView) findViewById(R.id.star17);
        tvstar18= (TextView) findViewById(R.id.star18);
        tvstar19= (TextView) findViewById(R.id.star19);
        tvstar20= (TextView) findViewById(R.id.star20);
        tvstar21= (TextView) findViewById(R.id.star21);
        tvstar22= (TextView) findViewById(R.id.star22);
        tvstar23= (TextView) findViewById(R.id.star23);
        tvstar24= (TextView) findViewById(R.id.star24);

        rollDices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int dice1 = randomDiceValue();
                int dice2 = randomDiceValue();
                int count1=map.getOrDefault(dice1, 0);
                map.put(dice1, count1+1);
                int count2=map.getOrDefault(dice2, 0);
                map.put(dice2, count2+1);

                sum = dice1 + dice2;
                total += sum;

                int res1 = getResources().getIdentifier("dice_" + dice1, "drawable", "umn.ac.id.rollthedice");
                int res2 = getResources().getIdentifier("dice_" + dice2, "drawable", "umn.ac.id.rollthedice");

                imageView1.setImageResource(res1);
                imageView2.setImageResource(res2);
                count++;
                tvcount.setText(Integer.toString(count));
                if(count==0) {
                    for (int j = 0; j < dice1; j++) {
                        star1 = star1.concat("*");
                        tvstar1.setText(star1);
                    }

                    for (int j = 0; j < dice2; j++) {
                        star2 = star2.concat("*");
                        tvstar2.setText(star2);
                    }
                }
                if(count==1) {
                    for (int j = 0; j < dice1; j++) {
                        star3 = star3.concat("*");
                        tvstar3.setText(star3);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star4 = star4.concat("*");
                        tvstar4.setText(star4);
                    }
                }
                if(count==2) {
                    for (int j = 0; j < dice1; j++) {
                        star5 = star5.concat("*");
                        tvstar5.setText(star5);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star6 = star6.concat("*");
                        tvstar6.setText(star6);
                    }
                }
                if(count==3) {
                    for (int j = 0; j < dice1; j++) {
                        star7 = star7.concat("*");
                        tvstar7.setText(star7);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star8 = star8.concat("*");
                        tvstar8.setText(star8);
                    }
                }
                if(count==4) {
                    for (int j = 0; j < dice1; j++) {
                        star9 = star9.concat("*");
                        tvstar9.setText(star9);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star10 = star10.concat("*");
                        tvstar10.setText(star10);
                    }
                }
                if(count==5) {
                    for (int j = 0; j < dice1; j++) {
                        star11 = star11.concat("*");
                        tvstar11.setText(star11);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star12 = star12.concat("*");
                        tvstar12.setText(star12);
                    }
                }
                if(count==6) {
                    for (int j = 0; j < dice1; j++) {
                        star13 = star13.concat("*");
                        tvstar13.setText(star13);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star14 = star14.concat("*");
                        tvstar14.setText(star14);
                    }
                }
                if(count==7) {
                    for (int j = 0; j < dice1; j++) {
                        star15 = star15.concat("*");
                        tvstar15.setText(star15);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star16 = star16.concat("*");
                        tvstar16.setText(star16);
                    }
                }
                if(count==8) {
                    for (int j = 0; j < dice1; j++) {
                        star17 = star17.concat("*");
                        tvstar17.setText(star17);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star18 = star18.concat("*");
                        tvstar18.setText(star18);
                    }
                }
                if(count==9) {
                    for (int j = 0; j < dice1; j++) {
                        star19 = star19.concat("*");
                        tvstar19.setText(star19);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star20 = star20.concat("*");
                        tvstar20.setText(star20);
                    }
                }
                if(count==10) {
                    for (int j = 0; j < dice1; j++) {
                        star21 = star21.concat("*");
                        tvstar21.setText(star21);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star22 = star22.concat("*");
                        tvstar22.setText(star22);
                    }
                }
                if(count == 11) {
                    for (int j = 0; j < dice1; j++) {
                        star23 = star23.concat("*");
                        tvstar23.setText(star23);
                    }
                    for (int j = 0; j < dice2; j++) {
                        star24 = star24.concat("*");
                        tvstar24.setText(star24);
                    }
                }
                if(count == 12) {
                    tvtotal.setText(Integer.toString(total));
                    mean = total / 12;
                    tvmean.setText(Float.toString(mean));
                    int maxValue=-1;
                    int key=0;
                    for(Map.Entry<Integer,Integer> entry : map.entrySet()) {
                        if(entry.getValue() > maxValue) {
                            maxValue = entry.getValue();
                            key = entry.getKey();
                        }
                    }
                    tvmaxValue.setText(Integer.toString(maxValue));
                    tvkey.setText(Integer.toString(key));
                }
                if(count >= 13) {
                    startActivity(new Intent(MainActivity.this, MenuActivity.class));
                    finish();
                }
            }
        });
        keluar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(MainActivity.this, MenuActivity.class));
                finish();
            }
        });
    }

    public static int randomDiceValue() {
        return RANDOM.nextInt(6) + 1;
    }
}